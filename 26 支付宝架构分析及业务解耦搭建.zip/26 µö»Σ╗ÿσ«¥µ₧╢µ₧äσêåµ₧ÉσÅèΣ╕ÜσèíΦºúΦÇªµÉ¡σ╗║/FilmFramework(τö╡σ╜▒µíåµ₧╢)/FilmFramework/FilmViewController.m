//
//  FilmViewController.m
//  FilmFramework
//
//  Created by 徐金城 on 2019/11/20.
//  Copyright © 2019 xujincheng. All rights reserved.
//

#import "FilmViewController.h"

@interface FilmViewController ()

@end

@implementation FilmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
