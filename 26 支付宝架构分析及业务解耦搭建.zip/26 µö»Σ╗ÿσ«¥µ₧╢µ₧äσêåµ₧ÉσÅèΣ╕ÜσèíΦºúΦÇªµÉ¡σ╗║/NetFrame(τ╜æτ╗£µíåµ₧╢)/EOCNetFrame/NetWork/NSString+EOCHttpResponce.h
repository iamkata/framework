//
//  NSString+TLHttpResponce.h
//  EOCAFCacheClass
//
//  Created by iMac on 17/5/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(EOCHttpResponceCache)

- (NSString *)md5Encrypt;
+ (NSString *)appVersionString;
+ (NSString *)cacheFileKeyNameWithUrlstring:(NSString* )urlString method:(NSString*)method parameters:(NSDictionary *)parameters;

@end



@interface NSEOCError : NSObject

@property(nonatomic, strong)NSString *errorDescription;
@property(nonatomic, strong)NSString *errorCode;
@property(nonatomic, strong)NSError *sysError;

@end



