//
//  TLRequestManager.m
//  EOCAFCacheClass
//
//  Created by iMac on 17/5/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCRequestManager.h"
#import "EOCHttpResponceCache.h"
#import "AFNetworking.h"
#import "NSString+EOCHttpResponce.h"

@interface EOCRequestManager ()
@property (nonatomic,strong) AFHTTPRequestOperationManager *requestManager;
@property (nonatomic,strong) NSMutableArray *batchGroups;//批处理
@property (nonatomic,strong) NSMutableDictionary *chainedOperations;

@property (nonatomic,strong) NSMapTable *operationMethodParameters; //保存opeation参数

@end


@implementation EOCRequestManager

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.cache = [EOCHttpResponceCache sharedCache];
        self.operationMethodParameters = [NSMapTable mapTableWithKeyOptions:NSMapTableWeakMemory valueOptions:NSMapTableStrongMemory];
        
    }
    
    return self;
}


+ (instancetype)sharedInstance
{
    static EOCRequestManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (AFHTTPRequestOperationManager *)requestManager
{
    if (!_requestManager) {
        _requestManager = [AFHTTPRequestOperationManager manager];
        _requestManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        _requestManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/json", @"text/javascript",@"text/plain", nil];
        _requestManager.requestSerializer.timeoutInterval = 30;
    }
    return _requestManager;
}


- (AFHTTPRequestOperation *)createOperationWithRequest:(NSURLRequest *)request
{
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
//    operation.responseSerializer = self.requestManager.responseSerializer;
//    operation.shouldUseCredentialStorage = self.requestManager.shouldUseCredentialStorage;
//    operation.credential = self.requestManager.credential;
//    operation.securityPolicy = self.requestManager.securityPolicy;
//    operation.completionQueue = self.requestManager.completionQueue;
//    operation.completionGroup = self.requestManager.completionGroup;
    return operation;
}

//判断是不是需要跳过缓存数据
-(BOOL)checkIfShouldSkipCacheFileWithCacheDuration:(NSTimeInterval)resultCacheDuration cacheKey:(NSString*)urlkey{
    if (resultCacheDuration == 0) {//如果不需要缓存
        return YES;
    }
    
    //处理缓存
    id result = [self.cache objectForKey:urlkey]; // 返回缓存
    if (result) {//如果有缓存判断实效性
        if ([self.cache expiredWithCacheKey:urlkey cacheDuration:resultCacheDuration]) { //如果存在，判断缓存文件是否过期了
            return YES;
        }
    }else{
        return YES;
    }
    return NO;
}

//对request的 响应 进行一些处理
- (void)handleResponseWithOperation:(AFHTTPRequestOperation*)operation
                             result:(id)responseObject//有错误把错误的实例作为参数，没有错误就把返回数据作为参数
                            isCache:(BOOL)isCache
                  completionHandler:(EOCRequestCompletionHandler)completionHandler{
    
    
    //可以先对responseObject数据进行与判断，错误的数据直接停止处理1
    NSEOCError* error = nil;
    id result = nil;
    
    if ([responseObject isKindOfClass:[NSError class]])
    {
        error = [NSEOCError new];
        error.errorCode = @"404";
        error.errorDescription = @"网络异常";
        error.sysError = responseObject;
    }
    else
    {
        result = [self decodeResponseObject:responseObject error:&error];
        if (result == [NSNull null])
            result = nil;
    }
    if (completionHandler)
    {
        if ([result isKindOfClass:[NSDictionary class]])
        {
            int temp = [[result objectForKey:@"code"] intValue];
            // 统一处理特定的错误
            if (temp == 999 || temp == 998 || temp == 209)
            {
                if (!error)
                    error = [NSEOCError new];
                error.errorCode = [result objectForKey:@"code"];
                error.errorDescription = [result objectForKey:@"msg"];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"loginOutNotification" object:nil];
            }
        }
        else
        {
            if (!error)
                error = [NSEOCError new];
            error.errorCode = @"404";
            error.errorDescription = @"网络连接失败,请检查网络";
        }
        completionHandler(error,result,isCache,operation);
    }
    
}

// 对响应结果做处理 格式
- (id)decodeResponseObject:(id)responseObject error:(NSEOCError **)error
{
    if ([responseObject isKindOfClass:[NSData class]])
    {
        return [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
    }
    else if([responseObject isKindOfClass:[NSDictionary class]])
    {
        return responseObject;
    }
    return nil;
}

- (AFHTTPRequestOperation *)startOperation:(AFHTTPRequestOperation *)operation
{
    NSDictionary *methodParameters = [self.operationMethodParameters objectForKey:operation];
    AFHTTPRequestOperation *newOperation = operation;
    if (methodParameters) {
        newOperation = [self HttpRequestWithMethod:methodParameters[@"method"]
                                         URLString:methodParameters[@"URLString"]
                                        parameters:methodParameters[@"parameters"]
                                startImmediately:YES
                                    ignoreCache:[methodParameters[@"ignoreCache"] boolValue]
                                        resultCacheDuration:[methodParameters[@"resultCacheDuration"] doubleValue]
                                  extend:methodParameters[@"constructingBodyWithBlock"]
                                          completionHandler:methodParameters[@"completionHandler"]];
        [self.operationMethodParameters removeObjectForKey:operation];
    } else {
        [self.requestManager.operationQueue addOperation:operation];
    }
    return newOperation;
}

/**
 *  从 Chained Operations 中找到该 Operation 对应的下一个 Operation
 *  注意：会从 Chain 中移除该 Operation!
 */
- (AFHTTPRequestOperation *)findNextOperationInChainedOperationsBy:(AFHTTPRequestOperation *)operation
{
    //TODO 这个实现有优化空间
    __block AFHTTPRequestOperation *theOperation;
    __weak typeof(self) weakSelf = self;
    
    [self.chainedOperations enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSMutableArray *chainedOperations, BOOL *stop) {
        [chainedOperations enumerateObjectsUsingBlock:^(AFHTTPRequestOperation *requestOperation, NSUInteger idx, BOOL *stop) {
            if (requestOperation == operation) {
                if (idx < chainedOperations.count - 1) {
                    theOperation = chainedOperations[idx + 1];
                    *stop = YES;
                }
                [chainedOperations removeObject:requestOperation];
                // 同时移除对要返回的 operation 的引用
                [chainedOperations removeObject:theOperation];
            }
        }];
        if (chainedOperations) {
            *stop = YES;
        }
        if (!chainedOperations.count) {
            [weakSelf.chainedOperations removeObjectForKey:key];
        }
    }];
    
    return theOperation;
}


- (AFHTTPRequestOperation *)HttpRequestWithMethod:(NSString *)method
                                        URLString:(NSString *)URLString
                                       parameters:(NSDictionary *)parameters
                                 startImmediately:(BOOL)startImmediately
                                      ignoreCache:(BOOL)ignoreCache
                              resultCacheDuration:(NSTimeInterval)resultCacheDuration
                                           extend:(EOCExtendBlock)extendBlock
                                completionHandler:(EOCRequestCompletionHandler)completionHandler

{
    
    if (![method isEqual:@"GET"]){
        method = @"POST";
    }
    
    // 添加统一字段
    if (parameters)
    {
        parameters = parameters.mutableCopy;
        // token
        //[parameters setValue:@"111" forKey:@"token"];
    }
    
    //创建 请求 1
    NSMutableURLRequest *request;
    request = [self.requestManager.requestSerializer requestWithMethod:method
                                                             URLString:URLString
                                                            parameters:parameters error:nil];
    
    
    //请求头 暂未配置
    
    //
    AFHTTPRequestOperation *operation = [self createOperationWithRequest:request];
    
    if (!startImmediately) { // 不开启任务
        /* 用来生成AFHTTPRequestOperation 执行AFHTTPRequestOperation需要另外操作
            把数据存储，保存
        */
        
        //保存代码如下： 可以把key定义成 宏🌈
        NSMutableDictionary *methodParameters = [NSMutableDictionary dictionaryWithObjectsAndKeys:method, @"method", nil];
        if (URLString) {
            [methodParameters setObject:URLString forKey:@"URLString"];
        }
        if (parameters) {
            [methodParameters setObject:parameters forKey:@"parameters"];
        }
        
        if (resultCacheDuration) {
            [methodParameters setObject:@(resultCacheDuration) forKey:@"resultCacheDuration"];
        }
        
        if (ignoreCache) {
            [methodParameters setObject:@(ignoreCache) forKey:@"ignoreCache"];
        }
        if (extendBlock) {
            [methodParameters setObject:extendBlock forKey:@"extendBlock"];
        }
        if (completionHandler) {
            [methodParameters setObject:completionHandler forKey:@"completionHandler"];
        }
        
        [self.operationMethodParameters setObject:methodParameters forKey:operation];
        return operation;
    }
    
    // 请求开始之前,检查相关内容看是不是 需要取消这个请求, 从缓存的获取
    // 生成一个ulr对应文件名（urlKey）
    NSString *urlKey = [NSString cacheFileKeyNameWithUrlstring:URLString method:method parameters:parameters];
    
    // 检查是否有缓存  过期是YES
    if ([self checkIfShouldSkipCacheFileWithCacheDuration:resultCacheDuration cacheKey:urlKey] || ignoreCache)
    {//执行没有缓存的操作
    configOperation:
        
        // 配置AF任务的 Completionblock 可以统一配置信息
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *theOperation, id responseObject){
            
            [self handleResponseWithOperation:theOperation result:responseObject isCache:NO completionHandler:completionHandler];
           
            if (resultCacheDuration > 0 )// 如果使用缓存，就把结果放到缓存中方便下次使用
            {
                // 文件名
                NSString *urlKey = [NSString cacheFileKeyNameWithUrlstring:URLString method:method parameters:parameters];
                [self.cache setObject:responseObject forKey:urlKey];
            }
            
        } failure:^(AFHTTPRequestOperation *theOperation, NSError *error){
            
            if (error.code != NSURLErrorCancelled) {
                [self handleResponseWithOperation:theOperation result:error isCache:NO completionHandler:completionHandler];
            }
        }];
        
        [self.requestManager.operationQueue addOperation:operation];
    }
    else
    { // AF
        id result = [self.cache objectForKey:urlKey];
        if (result) {//如果需要使用缓存则判断缓存是不是存在，不存在的话这继续获取新的数据
            [self handleResponseWithOperation:operation result:result isCache:YES completionHandler:completionHandler];
        }
        else
        {
            goto configOperation;
        }
    }
    return operation;
}

- (void)batchOfRequestOperations:(NSArray *)operations
                   progressBlock:(void (^)(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations))progressBlock
                 completionBlock:(netSuccessbatchBlock)completionBlock{
    
    __block dispatch_group_t group = dispatch_group_create();
    [self.batchGroups addObject:group];
    __block NSInteger finishedOperationsCount = 0;
    NSInteger totalOperationsCount = operations.count;
    
    [operations enumerateObjectsUsingBlock:^(AFHTTPRequestOperation *operation, NSUInteger idx, BOOL *stop) {
        
        NSMutableDictionary *operationMethodParameters = [[self.operationMethodParameters objectForKey:operation] mutableCopy];
        if (operationMethodParameters)
        {
            dispatch_group_enter(group);
            // 获取参数
            [self.operationMethodParameters setObject:operationMethodParameters forKey:operation];
            NSTimeInterval resultCacheDuration = [[operationMethodParameters objectForKey:@"resultCacheDuration"] doubleValue];
            NSDictionary *parameters = [operationMethodParameters objectForKey:@"parameters"];
            NSString *method = [[operationMethodParameters objectForKey:@"parameters"] description];
            NSString *URLString = [[operationMethodParameters objectForKey:@"URLString"] description];
            BOOL ignoreCache = NO;
            if ([operationMethodParameters objectForKey:@"ignoreCache"])
                ignoreCache = [[operationMethodParameters objectForKey:@"ignoreCache"] boolValue];
            NSString *urlKey = [NSString cacheFileKeyNameWithUrlstring:URLString method:method parameters:parameters];
            
            // 修改Block
            EOCRequestCompletionHandler originCompletionHandler = (EOCRequestCompletionHandler)[operationMethodParameters[@"completionHandler"] copy];
            
            EOCRequestCompletionHandler newCompletionHandler = ^(NSEOCError *error, id result, BOOL isFromCache, AFHTTPRequestOperation *theOperation) {
                if (!isFromCache) {
                    if (progressBlock) {
                        progressBlock(++finishedOperationsCount, totalOperationsCount);
                    }
                    if (resultCacheDuration > 0 )// 如果使用缓存，就把结果放到缓存中方便下次使用
                    {
                        NSString *urlKey = [NSString cacheFileKeyNameWithUrlstring:URLString method:method parameters:parameters];
                        
                        if (result)  // 因为文件类型的没有处理，result返回的是一个空，需要从heOperation.responseData获取
                            [self.cache setObject:result forKey:urlKey];
                        else
                            [self.cache setObject:theOperation.responseData forKey:urlKey];
                    }
                }
               
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (originCompletionHandler) {
                        originCompletionHandler(error, result, isFromCache, theOperation);
                    }
                    dispatch_group_leave(group);
                });
            };
            operationMethodParameters[@"completionHandler"] = newCompletionHandler;
            
            
            //判断是不是需要跳过缓存
            if ([self checkIfShouldSkipCacheFileWithCacheDuration:resultCacheDuration cacheKey:urlKey] || ignoreCache)
            {
                [self startOperation:operation];
            }
            else
            {
                id result = [self.cache objectForKey:urlKey];
                if (result) {//如果需要使用缓存则判断缓存是不是存在，不存在的话这继续获取新的数据
                    NSEOCError *error = nil;
                    newCompletionHandler(error, result, YES, operation);
            
                }
                else
                {
                    [self startOperation:operation];
                }
            }
            
        }
    }];
    
    //监听
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        [self.batchGroups removeObject:group];
        if (completionBlock) {
            completionBlock(operations);
        }
    });
}

- (void)dealloc
{
    
}

@end
