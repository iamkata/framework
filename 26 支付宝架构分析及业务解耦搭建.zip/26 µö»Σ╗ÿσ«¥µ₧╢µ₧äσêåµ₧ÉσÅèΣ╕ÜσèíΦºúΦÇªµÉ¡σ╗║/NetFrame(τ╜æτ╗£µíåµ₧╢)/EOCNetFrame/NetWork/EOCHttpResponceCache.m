//
//  HNHttpResponceCache.m
//  EOCAFCacheClass
//
//  Created by iMac on 17/5/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCHttpResponceCache.h"

#pragma -mark 缓存类
static NSString *  EOCCacheFileProcessingQueue = @"com.EOC.Class"; // 文件IO处理队列
static NSString *  EOCCacheDirectory = @"EOCClassCache"; // 缓存文件夹

static const NSInteger kHNDefaultCacheMaxCacheAge = 60 * 60 * 24 * 7; // 1 周

@interface EOCAutoPurgeCache : NSCache

@end

@implementation EOCAutoPurgeCache
- (id)init{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(removeAllObjects) name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
    }
    return self;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
}

-(void)removeAllObjects{
    
    [super removeAllObjects];
    
}
@end



@interface EOCHttpResponceCache ()
//用来保护受保护的 缓存文件
@property (strong, nonatomic) NSMutableSet *protectCaches;
@end

@implementation EOCHttpResponceCache
{
    EOCAutoPurgeCache        *_memoryCache;//cache 用来解决频繁从文件系统中 读取文件的 系能问题
    NSString                 *_cachePath;
    NSFileManager            *_fileManager;
    dispatch_queue_t         _EOCIOQueue;
}

#pragma -mark 生命周期
+(instancetype)sharedCache
{
    static id sharedCache = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedCache = [[EOCHttpResponceCache alloc] init];
    });
    return sharedCache;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _memoryCache = [[EOCAutoPurgeCache alloc] init];
        _EOCIOQueue = dispatch_queue_create([EOCCacheFileProcessingQueue UTF8String], DISPATCH_QUEUE_CONCURRENT);
        _maxCacheAge = kHNDefaultCacheMaxCacheAge;
        dispatch_sync(_EOCIOQueue, ^{
            _fileManager = [NSFileManager new];
            // 要判断是否有文件EOCClassCache存在，如果存在，干掉，创建EOCClassCache文件夹
            [self checkDirectory];
        });
        // 缓存清除操作放到退出后台操作
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(backgroundCleanDisk)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma -mark init

-(NSMutableSet*)protectCaches{
    if (!_protectCaches) {
        _protectCaches = [[NSMutableSet alloc] initWithCapacity:10];
    }
    return _protectCaches;
}

#pragma -mark 清理策略
//清除过期的内存
- (void)backgroundCleanDisk {
   
    UIApplication *application = [UIApplication sharedApplication];
    // EOCClass
    __block UIBackgroundTaskIdentifier bgTask = [application beginBackgroundTaskWithExpirationHandler:^{
        
        [application endBackgroundTask:bgTask];
        bgTask = UIBackgroundTaskInvalid;
        
    }];
    
    [self cleanDiskWithCompletionBlock:^{
        [application endBackgroundTask:bgTask];
        bgTask = UIBackgroundTaskInvalid;
    }];
}

/*
 
 同一个网络请求下载完后，存储的，fileA（本地存储是一个星期）
 在去请求实效是60s， 60s过后还是在的，如果改变了实效（120），如果没有改变还是60s，那么重新请求，替换fileA的内容了（那么这个fileA的ModificationDate也变了）
 
 实效性  删除
  删除机制
 
 */
//注意 这里如果是首页这种数据是不应该清除的 其他不应该清除的数据 即时添加
- (void)cleanDiskWithCompletionBlock:(void (^)(void))completionBlock {
    dispatch_async(_EOCIOQueue, ^{
        NSURL *diskCacheURL = [NSURL fileURLWithPath:_cachePath isDirectory:YES];
        NSArray *resourceKeys = @[NSURLLocalizedNameKey,NSURLNameKey,NSURLIsDirectoryKey, NSURLContentModificationDateKey, NSURLTotalFileAllocatedSizeKey];
        
        // 获取文件夹下的文件枚举
        NSDirectoryEnumerator *fileEnumerator = [_fileManager enumeratorAtURL:diskCacheURL
                                                   includingPropertiesForKeys:resourceKeys
                                                                      options:NSDirectoryEnumerationSkipsHiddenFiles
                                                                 errorHandler:NULL];
    
        // 过期时间 expirationDate
        NSDate *expirationDate = [NSDate dateWithTimeIntervalSinceNow:-self.maxCacheAge];
        NSMutableDictionary *cacheFiles = [NSMutableDictionary dictionary];
        NSUInteger currentCacheSize = 0;
        
        // 遍历缓存文件夹中的所有文件，有2 个目的
        //  1. 删除过期的文件
        //  2. 删除比较的旧的文件 使得当前文件的大小 小于最大文件的大小
        NSMutableArray *urlsToDelete = [[NSMutableArray alloc] init];
        for (NSURL *fileURL in fileEnumerator) {
            NSDictionary *resourceValues = [fileURL resourceValuesForKeys:resourceKeys error:NULL];
            // 跳过文件夹
            if ([resourceValues[NSURLIsDirectoryKey] boolValue]) {
                continue;
            }
            
            // 跳过指定不能删除的文件 比如首页列表数据
            if ([self.protectCaches containsObject:fileURL.lastPathComponent]) {
                continue;
            }
            
            // 删除过期文件 EOCClass
            NSDate *modificationDate = resourceValues[NSURLContentModificationDateKey];
            if ([[modificationDate laterDate:expirationDate] isEqualToDate:expirationDate]) {
                [urlsToDelete addObject:fileURL];
                continue;
            }

            NSNumber *totalAllocatedSize = resourceValues[NSURLTotalFileAllocatedSizeKey];
            currentCacheSize += [totalAllocatedSize unsignedIntegerValue];
            [cacheFiles setObject:resourceValues forKey:fileURL];
        }
        
        for (NSURL *fileURL in urlsToDelete) {
            [_fileManager removeItemAtURL:fileURL error:nil];
        }
        
        
        // 如果删除过期的文件后，缓存的总大小还大于maxsize 的话则删除比较快老的缓存文件
        if (self.maxCacheSize > 0 && currentCacheSize > self.maxCacheSize) {
            // 这个过程主要清除到最大缓存的一半大小
            const NSUInteger desiredCacheSize = self.maxCacheSize / 2;
            
            // 按照最后的修改时间来排序，旧的文件排在前面
            NSArray *sortedFiles = [cacheFiles keysSortedByValueWithOptions:NSSortConcurrent
                                                            usingComparator:^NSComparisonResult(id obj1, id obj2) {
                                                                return [obj1[NSURLContentModificationDateKey] compare:obj2[NSURLContentModificationDateKey]];
                                                            }];
            //删除文件到一半的大小
            for (NSURL *fileURL in sortedFiles) {
                if ([_fileManager removeItemAtURL:fileURL error:nil]) {
                    NSDictionary *resourceValues = cacheFiles[fileURL];
                    NSNumber *totalAllocatedSize = resourceValues[NSURLTotalFileAllocatedSizeKey];
                    currentCacheSize -= [totalAllocatedSize unsignedIntegerValue];
                    if (currentCacheSize < desiredCacheSize) {
                        break;
                    }
                }
            }
        }
        
        if (completionBlock) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completionBlock();
            });
        }
    });
}

- (void)clearCacheOnDisk {
    [self clearCacheOnDisk:nil];
}

- (void)clearCacheOnDisk:(void (^)(void))completion
{
    dispatch_async(_EOCIOQueue, ^{
        [_fileManager removeItemAtPath:_cachePath error:nil];
        [_fileManager createDirectoryAtPath:_cachePath
                withIntermediateDirectories:YES
                                 attributes:nil
                                      error:NULL];
        
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion();
            });
        }
    });
}

//删除指定到哪一天的缓存
- (void)deleteCacheToDate:(NSDate *)date
{
    __autoreleasing NSError *error = nil;
    NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL URLWithString:_cachePath]
                                                   includingPropertiesForKeys:@[NSURLContentModificationDateKey]
                                                                      options:NSDirectoryEnumerationSkipsHiddenFiles
                                                                        error:&error];
    if (error) {
        NSLog(@"获取缓存列表失败:%@", error);
    }
    
    dispatch_async(_EOCIOQueue, ^{
        for (NSURL *fileURL in files) {
            NSDictionary *dictionary = [fileURL resourceValuesForKeys:@[NSURLContentModificationDateKey] error:nil];
            NSDate *modificationDate = [dictionary objectForKey:NSURLContentModificationDateKey];
            if (modificationDate.timeIntervalSince1970 - date.timeIntervalSince1970 < 0) {
                [[NSFileManager defaultManager]  removeItemAtPath:fileURL.absoluteString error:nil];
            }
        }
    });
}

- (void)removeObjectForKey:(NSString *)key
{
    [_memoryCache removeObjectForKey:key];
    NSString *filePath = [_cachePath stringByAppendingPathComponent:key];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        __autoreleasing NSError *error = nil;
        BOOL removed = [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
        if (!removed) {
            NSLog(@"删除缓存失败:%@", error);
        }
    }
}

#pragma -mark 工具
//判断一个文件是不是过期
-(BOOL)expiredWithCacheKey:(NSString*)cacheFileNamekey cacheDuration:(NSTimeInterval)expirationDuration{
    NSString *filePath = [_cachePath stringByAppendingPathComponent:cacheFileNamekey];
    BOOL fileExist = [_fileManager fileExistsAtPath:filePath];
    if (fileExist) {
        NSTimeInterval fileDuration = [self cacheFileDuration:filePath];
        return fileDuration > expirationDuration;
    }else{
        return YES;//如果文件不存在 则设置为  过期文件
    }
}

// 获取文件的修改日期
- (NSTimeInterval)cacheFileDuration:(NSString *)path {
    NSError *attributesRetrievalError = nil;
    NSDictionary *attributes = [_fileManager attributesOfItemAtPath:path
                                                             error:&attributesRetrievalError];
    if (!attributes) {
        NSLog(@"获取文件属性失败 %@: %@", path, attributesRetrievalError);
        return -1;
    }
    // 文件的修改时间
    NSTimeInterval seconds = -[[attributes fileModificationDate] timeIntervalSinceNow];
    return seconds;
}



//检查缓存文件夹 如果没有就创建缓存文件夹文件夹
- (void)checkDirectory
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    _cachePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:EOCCacheDirectory];
    BOOL isDir;
    if (![_fileManager fileExistsAtPath:_cachePath isDirectory:&isDir]) {
        [self createBaseDirectoryAtPath];
    }else{
        if (!isDir) { // 如果不是文件夹
            NSError *error = nil;
            [_fileManager removeItemAtPath:_cachePath error:&error];
            [self createBaseDirectoryAtPath];
        }
    }
}

//创建 缓存文件夹
- (void)createBaseDirectoryAtPath{
    __autoreleasing NSError *error = nil;
    BOOL created = [[NSFileManager defaultManager] createDirectoryAtPath:_cachePath withIntermediateDirectories:YES attributes:nil error:&error];
    if (!created) {
        NSLog(@"创建 缓存文件夹失败:%@", error);
    }else{
        NSURL *url = [NSURL fileURLWithPath:_cachePath];
        NSError *error = nil;
        //避免缓存数据 被备份到iclouds
        [url setResourceValue:[NSNumber numberWithBool:YES] forKey:NSURLIsExcludedFromBackupKey error:&error];
        if (error) {
            NSLog(@"没有成功的设置 ‘应用不能备份的属性’, error = %@", error);
        }
    }
}

-(void)addProtectCacheKey:(NSString*)key{
    [self.protectCaches addObject:key];
}

#pragma -mark 读写

- (void)setObject:(id<NSCoding>)object forKey:(NSString *)key{
    if (!object) {
        return;
    }
    [_memoryCache setObject:object forKey:key];
    dispatch_async(_EOCIOQueue, ^{
        NSString *filePath = [_cachePath stringByAppendingPathComponent:key];
        BOOL written = [NSKeyedArchiver archiveRootObject:object toFile:filePath];
        if (!written) {
            NSLog(@"写入缓存失败");
        }
    });
}
/*
 先读NSCache， 然后读文件
 */
- (id <NSCoding>)objectForKey:(NSString *)key{
    id<NSCoding> object = [_memoryCache objectForKey:key];
    if (!object) {
        NSString *filePath = [_cachePath stringByAppendingPathComponent:key];
        if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            object = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
            [_memoryCache setObject:object forKey:key];//add by lilin
        }
    }
    return object;
}
@end
