//
//  ViewController.m
//  EOCNetTest
//
//  Created by EOC on 2017/7/26.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ViewController.h"
#import "EOCRequestManager.h"

#define URLPath @"http://svr.tuliu.com/center/front/app/util/updateVersions"
// versions_id=1&system_type=1

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self eocNet];
}


- (void)eocNet{
    NSString* urlStr = URLPath;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    [parameters setObject:@"1" forKey:@"versions_id"];
    [parameters setObject:@"1" forKey:@"system_type"];
    [[EOCRequestManager sharedInstance] HttpRequestWithMethod:@"POST"
                                                    URLString:urlStr
                                                   parameters:parameters
                                             startImmediately:YES
                                                  ignoreCache:NO
                                          resultCacheDuration:3
                                                       extend:nil
                                            completionHandler:^(NSEOCError *error, id result, BOOL isFromCache, AFHTTPRequestOperation *operation){
                                                
                                                if (error) {
                                                    NSLog(@"%@", error);
                                                }else{
                                                    
                                                    NSLog(@"%@", result);
                                                }
                                                
                                            }];
    
}


@end
