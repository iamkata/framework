//
//  MTabBarButton.m
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "MTabBarButton.h"

@implementation MTabBarButton


- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        [self setTitleColor:[UIColor yellowColor] forState:UIControlStateNormal];
        [self setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
    }
    return self;
}

- (void)layoutSubviews{
    
    [super layoutSubviews];
    self.imageView.x = (self.width-22)/2;
    self.imageView.y = 7;
    self.imageView.size = CGSizeMake(22, 22);
    
    self.titleLabel.x = 0;
    self.titleLabel.y = self.imageView.bottom;
    self.titleLabel.size = CGSizeMake(self.width, self.height - (self.imageView.bottom));
    self.titleLabel.font = [UIFont systemFontOfSize:10];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
}

- (void)setSelected:(BOOL)selected{
    
    [super setSelected:selected];
    
    if (selected) {
        self.titleLabel.textColor = [UIColor redColor];
    }else{
        self.titleLabel.textColor = [UIColor yellowColor];
    }
    
}

@end
