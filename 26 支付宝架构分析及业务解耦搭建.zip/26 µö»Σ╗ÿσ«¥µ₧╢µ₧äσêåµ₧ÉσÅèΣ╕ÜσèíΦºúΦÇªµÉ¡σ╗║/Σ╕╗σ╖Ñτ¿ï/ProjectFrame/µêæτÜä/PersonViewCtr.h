//
//  PersonViewCtr.h
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//


@interface PersonViewCtr : UIViewController{
    
    
    
}

@end
