//
//  PersonRoute.m
//  XPSPlatform
//
//  Created by sy on 2017/12/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "PersonRoute.h"
#import "PersonViewCtr.h"

@implementation PersonRoute

- (UIViewController*)controllerWithMainTabbar{
    
    return [PersonViewCtr new];
    
}

@end
