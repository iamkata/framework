//
//  PersonRoute.h
//  XPSPlatform
//
//  Created by sy on 2017/12/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PersonRoute : NSObject

- (UIViewController*)controllerWithMainTabbar;

@end
