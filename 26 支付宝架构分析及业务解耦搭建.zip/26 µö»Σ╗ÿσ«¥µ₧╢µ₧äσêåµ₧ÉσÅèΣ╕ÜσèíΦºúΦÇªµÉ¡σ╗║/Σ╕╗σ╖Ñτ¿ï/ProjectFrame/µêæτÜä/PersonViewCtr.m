//
//  PersonViewCtr.m
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "PersonViewCtr.h"


@interface PersonViewCtr (){
    
}

@end

@implementation PersonViewCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"个人";
    
}

@end
