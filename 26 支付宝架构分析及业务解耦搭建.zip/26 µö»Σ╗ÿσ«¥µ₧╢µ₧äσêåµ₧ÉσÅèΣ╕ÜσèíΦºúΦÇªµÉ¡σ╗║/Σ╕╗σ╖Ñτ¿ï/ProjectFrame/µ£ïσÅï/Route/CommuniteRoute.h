//
//  CommuniteRoute.h
//  XPSPlatform
//
//  Created by sy on 2017/12/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommuniteRoute : NSObject

- (UIViewController*)controllerWithMainTabbar;

@end
