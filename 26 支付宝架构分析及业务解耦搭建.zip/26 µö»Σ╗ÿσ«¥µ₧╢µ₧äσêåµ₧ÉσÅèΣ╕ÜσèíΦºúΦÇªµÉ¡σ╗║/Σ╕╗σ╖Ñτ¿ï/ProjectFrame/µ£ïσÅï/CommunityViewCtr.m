//
//  CommunityViewCtr.m
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "CommunityViewCtr.h"


@interface CommunityViewCtr (){
    

    
}

@end

@implementation CommunityViewCtr

- (void)viewDidLoad {
    [super viewDidLoad];
 
    self.navigationItem.title = @"朋友";
}




@end
