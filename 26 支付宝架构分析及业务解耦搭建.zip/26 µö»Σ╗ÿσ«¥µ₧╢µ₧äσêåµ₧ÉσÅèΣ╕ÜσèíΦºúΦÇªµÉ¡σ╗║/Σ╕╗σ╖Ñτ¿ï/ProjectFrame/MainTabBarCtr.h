//
//  MainTabBarCtr.h
//  TuliuBroker
//
//  Created by iMac on 16/7/5.
//  Copyright © 2016年 tuliu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabBarCtr : UITabBarController{
    
    NSArray *tabTitleAry;
    NSArray *imageNormalNameAry;
    NSArray *imageHightNameAry;
    
    UIView *tabBarButtomView;
}

- (void)skipToLoginView;

@end
