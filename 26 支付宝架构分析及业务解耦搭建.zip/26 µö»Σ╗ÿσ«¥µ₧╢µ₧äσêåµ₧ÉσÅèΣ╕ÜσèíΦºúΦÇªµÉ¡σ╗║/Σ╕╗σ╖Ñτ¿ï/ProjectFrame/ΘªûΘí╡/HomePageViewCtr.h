//
//  HomePageViewCtr.h
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//


@interface HomePageViewCtr : UIViewController{
    
    IBOutlet UIView *_navBarView;
    IBOutlet UITableView *_tableView;
}

@end
