//
//  HomePageViewCtr.m
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "HomePageViewCtr.h"


@interface HomePageViewCtr (){
    
 
}

@end

@implementation HomePageViewCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"首页";
    self.view.backgroundColor = [UIColor redColor];
}


@end
