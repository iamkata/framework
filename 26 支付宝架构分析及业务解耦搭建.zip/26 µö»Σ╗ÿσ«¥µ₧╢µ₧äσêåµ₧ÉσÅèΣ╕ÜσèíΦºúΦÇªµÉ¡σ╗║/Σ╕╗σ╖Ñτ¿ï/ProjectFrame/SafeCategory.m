//
//  SafeCategory.m
//  ProjectFrame
//
//  Created by sy on 2018/1/19.
//  Copyright © 2018年 sy. All rights reserved.
//

#import "SafeCategory.h"

/*
 把函数名隐藏在结构体里，以函数指针成员的形式存储。
 编译后，只有留下地址，去掉了名字和参数表，提高了逆向成本和攻击门槛
 */

typedef struct SafeCatey{
    
    void(*resetPassword)(NSString* password);
    
} SafeCategoryOC;

//这个函数在结构体中就是个指针
static void _resetPassword(NSString* password){
    
    NSLog(@"设置密码");
}

#define SafeUnit ([SafeCategory shareSafeCategory])

@implementation SafeCategory


+ (SafeCategoryOC*)shareSafeCategory{
    
    static SafeCategoryOC *__safetCategory = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        __safetCategory = malloc(sizeof(SafeCategoryOC));
        __safetCategory->resetPassword = _resetPassword;
    });
    
    return __safetCategory;
}

//使用举例
- (void)testSafe:(NSString*)pswd{
    
    SafeUnit->resetPassword(pswd);
}

@end
