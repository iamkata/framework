//
//  TLRequestManager.h
//  EOCAFCacheClass
//
//  Created by iMac on 17/5/14.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>


@class EOCHttpResponceCache;
@class NSEOCError;
@class AFHTTPRequestOperation;

NS_ASSUME_NONNULL_BEGIN

typedef void (^EOCRequestCompletionHandler)(NSEOCError *error, id result, BOOL isFromCache, AFHTTPRequestOperation *operation);
typedef void (^EOCExtendBlock)(id formData, id formData2);
typedef void (^netSuccessHandleDataBlock)(NSDictionary *resultDict);
typedef void (^netSuccessbatchBlock)(NSArray *operationAry);

@interface EOCRequestManager : NSObject


@property (nonatomic, null_unspecified, strong) EOCHttpResponceCache *cache;//缓存 工具类

+ (nonnull instancetype)sharedInstance;

/**
 *  默认POST 方法
 *
 *  @param method              GET／POST
 *  @param URLString           ULR
 *  @param parameters          参数
 *  @param startImmediately    YES 马上执行; NO不马上执行 直接返回AFHTTPRequestOperation对象
 *  @param ignoreCache         是否忽略缓存 YES忽略;  NO不忽略, 使用缓存
 *  @param resultCacheDuration 该请求在缓存中存在的时间 -1 表示永久存储  0 表示不存储, 其他表示存储的对应时间(单位秒)
 *  @param completionHandler   处理结果
 *  @param extendBlock         扩展  暂时无用
 *
 *  @return 返回对应的请求
 */
- (AFHTTPRequestOperation *)HttpRequestWithMethod:(NSString *)method
                                        URLString:(NSString *)URLString
                                       parameters:(NSDictionary *)parameters
                                 startImmediately:(BOOL)startImmediately
                                      ignoreCache:(BOOL)ignoreCache
                              resultCacheDuration:(NSTimeInterval)resultCacheDuration
                                        extend:(__nullable EOCExtendBlock)extendBlock
                                 completionHandler:(__nullable EOCRequestCompletionHandler)completionHandler;



/**
 *  Description  并行执行多个任务
 *  并行执行operation  其实是有顺序的 这里先添加进入的先执行
 *  必须注意 添加到序列中的请求不能立即执行zz
 *  @param operations      线程数组(AFHTTPRequestOperation对象)
 *  @param progressBlock   进度
 *  @param completionBlock 完成handle
 */
- (void)batchOfRequestOperations:(NSArray *)operations
                   progressBlock:(void (^)(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations))progressBlock
                 completionBlock:(netSuccessbatchBlock)completionBlock;


@end

NS_ASSUME_NONNULL_END
