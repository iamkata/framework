//
//  ViewController.h
//  ProjectFrame
//
//  Created by sy on 2018/1/19.
//  Copyright © 2018年 sy. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 
 https://mp.weixin.qq.com/s/XZ5G-SqrpO8Etj7D5Y55Vw
 
 1 解耦
 
 一、
 1 一个工程如何多人开发 （独立开发，独立运行）
 2 模块话拆分， 横向分层-- 纵向梳理 （不同模块之间的关系导致 编译不过）
 3 组件化  （编译速度慢）  （pod sd） 关键在解耦
 4 稳定二进制包 （lib，frame）
 
 
 二 组件之间的解耦
 1 路由层，统跳协议
 
 三 安全问题 hook
 
 1 越狱 非越狱
 
 2 越狱 通过终端来直接操作你的app 运行时 runtime hook的你方法
   安全隐患 运行时导致，方法名和参数都能看到，
 
 解决:
   通过c的方法，把函数名隐藏在结构体里，以函数指针成员的形式存储。 编译后，只有留下地址，去掉了名字和参数表，提高了逆向成本和攻击门槛
 
 
 */

#define LoginMethod  xggedsagegawegga

- (void)LoginMethod:(NSString*)loginName{
    
    NSLog(@"loginMethod");
}

@interface ViewController : UIViewController


@end

