//
//  ViewController.m
//  ProjectFrame
//
//  Created by sy on 2018/1/19.
//  Copyright © 2018年 sy. All rights reserved.
//

#import "ViewController.h"

#define LoginMethod  xggedsagegawegga

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)LoginMethod:(NSString*)loginName{
    
    NSLog(@"loginMethod");
}


@end
