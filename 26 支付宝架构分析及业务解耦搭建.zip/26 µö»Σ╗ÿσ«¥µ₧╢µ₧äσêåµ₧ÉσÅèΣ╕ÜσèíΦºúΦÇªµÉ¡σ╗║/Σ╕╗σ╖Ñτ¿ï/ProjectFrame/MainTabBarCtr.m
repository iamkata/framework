//
//  MainTabBarCtr.m
//  TuliuBroker
//
//  Created by iMac on 16/7/5.
//  Copyright © 2016年 tuliu. All rights reserved.
//

#import "MainTabBarCtr.h"
#import "MTabBarButton.h"

@interface MainTabBarCtr (){
    
    UIButton *_currentSelectBt;
}
@end

@implementation MainTabBarCtr

// url
#pragma mark view life style

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self){
        
        tabTitleAry = [[NSArray alloc] initWithObjects:@"首页", @"口碑", @"朋友", @"我的", nil];
        imageNormalNameAry = [[NSArray alloc] initWithObjects:@"faxian-tabbar-nor.png",@"shequ-tabbar-nor.png", @"pingtai-tabbar-nor.png", @"wode-tabbar-nor.png",nil];
        imageHightNameAry  = [[NSArray alloc] initWithObjects:@"faxian-tabbar-act.png",@"shequ-tabbar-act.png", @"pingtai-tabbar-act.png", @"wode-tabbar-act.png",nil];
        
        //组件化之后,每个组件都有一个路由,负责其他和本模块的操作
        UIViewController *homePageViewCtr = [self routeTargetName:@"FindRoute" actionName:@"controllerWithMainTabbar"];
        UIViewController *communitViewCtr =  [self routeTargetName:@"CommuniteRoute" actionName:@"controllerWithMainTabbar"];
        UIViewController *finPlatformVCtr =  [self routeTargetName:@"PlatformRoute" actionName:@"controllerWithMainTabbar"];
        UIViewController *personViewCtr   =  [self routeTargetName:@"PersonRoute" actionName:@"controllerWithMainTabbar"];
        
        UINavigationController *baseNavOne   = [[UINavigationController alloc] initWithRootViewController:homePageViewCtr];
        UINavigationController *baseNavTwo   = [[UINavigationController alloc] initWithRootViewController:communitViewCtr];
        UINavigationController *baseNavThree = [[UINavigationController alloc] initWithRootViewController:finPlatformVCtr];
        UINavigationController *baseNavFour  = [[UINavigationController alloc] initWithRootViewController:personViewCtr];

        self.viewControllers = [[NSArray alloc] initWithObjects:baseNavOne, baseNavTwo, baseNavThree, baseNavFour, nil];
    }

    self.selectedIndex = 0;
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (!tabBarButtomView) {
        [self createTabarView];
    }
}

- (void)removeDefult
{
    
}


- (void)createTabarView{
    
    if (tabBarButtomView) {
        [tabBarButtomView removeFromSuperview];
    }
    tabBarButtomView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tabBar.frame.size.width, self.tabBar.frame.size.height)];
    tabBarButtomView.backgroundColor = [UIColor clearColor];
    
    UIView *backgroundView = [[UIView alloc] initWithFrame:tabBarButtomView.frame];
    backgroundView.backgroundColor = [UIColor blackColor];
    [tabBarButtomView addSubview:backgroundView];
    
    int btWidth = tabBarButtomView.frame.size.width/tabTitleAry.count;
    int btHeigh = tabBarButtomView.frame.size.height;
        
    for (int i = 0; i < tabTitleAry.count; i++){
        
        MTabBarButton *mTableBt = [[MTabBarButton alloc] initWithFrame:CGRectMake(i*btWidth, 0, btWidth, btHeigh)];
        [mTableBt setTitle:tabTitleAry[i] forState:UIControlStateNormal];
        [mTableBt setImage:[UIImage imageNamed:imageNormalNameAry[i] ]forState:UIControlStateNormal];
        [mTableBt setImage:[UIImage imageNamed:imageHightNameAry[i]] forState:UIControlStateSelected];
        [mTableBt addTarget:self action:@selector(tabBarItemPress:) forControlEvents:UIControlEventTouchUpInside];
        [tabBarButtomView addSubview:mTableBt];
        mTableBt.tag = i;
        if (i == self.selectedIndex){
            mTableBt.selected = YES;
            _currentSelectBt = mTableBt;
        }
    }
    for(UIView *view in [self.tabBar subviews]){
        
        view.hidden = YES;
    }
    tabBarButtomView.opaque = YES;
    // [self.tabBar insertSubview:tabBarButtomView atIndex:0];
    [self.tabBar addSubview:tabBarButtomView];
}


- (void)tabBarItemPress:(UIButton*)sender{
    
    if(sender == _currentSelectBt){
        return;
    }
    
    self.selectedIndex = sender.tag;
    sender.selected = !sender.selected;
    _currentSelectBt.selected = NO;
    _currentSelectBt = sender;
}

- (void)nextAction{
   
}


- (void)skipToLoginView{
   
}


@end
