//
//  TicketFramework.h
//  TicketFramework
//
//  Created by 徐金城 on 2019/11/20.
//  Copyright © 2019 xujincheng. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TicketFramework.
FOUNDATION_EXPORT double TicketFrameworkVersionNumber;

//! Project version string for TicketFramework.
FOUNDATION_EXPORT const unsigned char TicketFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TicketFramework/PublicHeader.h>


