//
//  FinPlatformVCtr.m
//  XPSPlatform
//
//  Created by sy on 2017/11/6.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "FinPlatformVCtr.h"

@interface FinPlatformVCtr ()

@end

@implementation FinPlatformVCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"口碑";
    self.navigationItem.leftBarButtonItem = nil;
    self.view.backgroundColor = [UIColor blueColor];
}

#pragma mark - Net


@end
