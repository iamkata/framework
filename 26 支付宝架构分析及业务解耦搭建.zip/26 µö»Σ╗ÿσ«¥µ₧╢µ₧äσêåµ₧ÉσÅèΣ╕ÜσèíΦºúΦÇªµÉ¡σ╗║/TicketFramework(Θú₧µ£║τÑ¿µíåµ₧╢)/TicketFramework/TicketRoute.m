//
//  TicketRoute.m
//  TicketFramework
//
//  Created by 徐金城 on 2019/11/20.
//  Copyright © 2019 xujincheng. All rights reserved.
//

#import "TicketRoute.h"
#import "TicketViewController.h"

@implementation TicketRoute

- (UIViewController*)ticketRootView{
    
    return [TicketViewController new];
}

@end
