//
//  ViewController.m
//  Tickettarget
//
//  Created by 徐金城 on 2019/11/20.
//  Copyright © 2019 xujincheng. All rights reserved.
//

#import "ViewController.h"
#import "TicketViewController.h"

@interface ViewController ()
 
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.navigationController pushViewController:[TicketViewController new] animated:YES];
}

@end
